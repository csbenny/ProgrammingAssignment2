class Order:
    def __init__(self, symbol:str, side: str, price:float, quantity: int):
        self.symbol = symbol
        self.side = side
        self.price = price
        self.quantity = quantity

    def __str__(self) -> str:
        return "{} order on {} with qty {} @ {}".format(
            "Buy" if self.side == "B" else "Sell", self.symbol, self.quantity, self.price)

    def __repr__(self) -> str:
        return "[Order:{}:{}:{}:{}]".format(self.side, self.symbol, self.price, self.quantity)

    def getSymbol(self):
        return self.symbol

    def getSide(self):
        return self.side

    def getPrice(self):
        return self.price

    def getQuantity(self):
        return self.quantity


def echo(s: str):
    print(s)

if "__main__" == "__main__":
    print("Program start")
    # name = input("What is your name: ")
    # echo(f"Hello {name}")

    o1 = Order('0005.HK', 'B', 56.5, 2000)
    o2 = Order('0005.HK', 'B', 56.5, 2000)

    print(o1)
    print(repr(o2))
