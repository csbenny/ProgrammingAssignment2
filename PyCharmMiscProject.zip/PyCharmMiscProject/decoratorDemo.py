from functools import wraps

def loggingWithUsingWraps(func):
    @wraps(func)
    def wrapper(*args, **kargs):
        print(f"Before: Calling the function '{func.__name__}' with args {args}, and kargs {kargs}")
        result = func(*args, **kargs)
        print(f"After: Calling the function '{func.__name__}'. Result = {result}")
        return result
    return wrapper

def loggingWrapperWithoutUsingWraps(func):
    def wrapper(*args, **kargs):
        print(f"Before: Calling the function '{func.__name__}' with args {args}, and kargs {kargs}")
        result = func(*args, **kargs)
        print(f"After: Calling the function '{func.__name__}'. Result = {result}")
        return result
    return wrapper

class Calculator:
    def __init__(self):
        self.name = 'Calculator'

    def __enter__(self):
        print(f'{self.name} entering context manager')
        return self

    def __exit__(self, exec_type, exc_value, traceback):
        print(f"{self.name} exiting content manager")

    def doSomething(self):
        print("Calculator is doing something")

    @loggingWithUsingWraps
    def addition(self, x:int, y:int) -> int:
        return x + y

    def multiply(self, x:int, y:int) -> int:
        return x * y

    def division(self, x:int, y:int) -> int:
        return x // y



def main():
    print('decoratorDemo start')

    tmp = addition(3,8)
    print(f"Result = {tmp}")
    print(f"addition function name: '{addition.__name__}'")
    print(f"addition function docstring: '{addition.__doc__}'")

    print("=" * 20)

    tmp = multiply(5,11)
    print(f"Result = {tmp}")
    print(f"multiply function name: '{multiply.__name__}'")
    print(f"multiply function docstring: '{multiply.__doc__}'")

    print("=" * 20)

    with Calculator() as calc:
        tmp = calc.addition(2,3)
        print(f"Result: {tmp}")

    print("decoratorDemo end")

@loggingWithUsingWraps
def multiply(x:int, y:int) -> int:
    """
    Perform multiplication of two input integers
    """
    return x * y

@loggingWrapperWithoutUsingWraps
def addition(x:int, y:int) -> int:
    """
    Perform an addition between two input integers
    """
    return x + y

if __name__ == '__main__':
    main()