import yaml
import json

class Employee:
    def __init__(self, name: str, age: int, department: str, employee_id: int, emergency_contact: list[str]):
        self.name = name
        self.age = age
        self.department = department
        self.employee_id = employee_id
        self.emergency_contact = emergency_contact

    def __str__(self) -> str:
        return f"Employee(name={self.name}, age={self.age}, department={self.department}, employee_id={self.employee_id}), emergency_contact={self.emergency_contact})"

def serialize_to_yaml(employee: Employee, filename: str):
    with open(filename, 'w') as file:
        yaml.dump(emp.__dict__, file, default_flow_style=False, sort_keys=False)
        print(f"Employee data has been serialized to {filename}")

def serialize_to_json(employee: Employee, filename: str):
    with open(filename, 'w') as file:
        json.dump(employee.__dict__, file, indent=2)
        print(f"Employee data has been serialized to {filename}")

if __name__ == "__main__":
    # Create an instance of Employee
    emp = Employee("Alice", 30, "Engineering", 12345,
                   ["Bob: 123-456-7890", "Charlie: 987-654-3210"])

    # Print the serialized YAML string
    yaml_str = yaml.dump(emp.__dict__, default_flow_style=False, sort_keys=False)
    print("--- Employee obj in YAML format ---")
    print(yaml_str)

    # Serialize the object in YAML format  and write to file
    print("--- Employee object __dict__ representation ---")
    print(emp.__dict__)

    serialize_to_yaml(emp, 'employee.yaml')

    serialize_to_json(emp, 'employee.json')

    # Deserialize back to a dictionary
    with open('employee.yaml', 'r') as file:
        emp_dict = yaml.safe_load(yaml_str)
        # Print the deserialized dictionary
        print(f"Type of emp_dict: {type(emp_dict)}")
        print(emp_dict)

    # Deserialize back to an Employee object
    with open('employee.json', 'r') as file:
        restore_emp_dict = json.load(file)
        print(f"Type of restore_emp_dict: {type(restore_emp_dict)}")
        print(restore_emp_dict)
        restore_emp = Employee(**restore_emp_dict)
        print(restore_emp)