import collections

class MyNonHashableObj:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return f"MyNonHashableObj({self.value})"

    def __eq__(self, other):
        if isinstance(other, MyNonHashableObj):
            return self.value == other.value
        return False

class MyHashableObj:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return f"MyHashableObj({self.value})"

class ComplexObj:
    def __init__(self, region, name, owner, groupId):
        self.region = region
        self.name = name
        self.owner = owner
        self.groupId = groupId

    def __eq__(self, other):
        if isinstance(other, ComplexObj):
            return (self.region == other.region and
                    self.name == other.name and
                    self.owner == other.owner and
                    self.groupId == other.groupId)
        return False

    def __hash__(self):
        return hash((self.region, self.name, self.owner, self.groupId))

if __name__ == "__main__":
    obj1 = MyHashableObj("Object 1")
    if isinstance(obj1, collections.abc.Hashable):
        print(f"{obj1} is hashable")
    else:
        print(f"{obj1} is not hashable")

    obj2 = MyNonHashableObj("Object 2")
    if isinstance(obj2, collections.abc.Hashable):
        print(f"{obj2} is hashable")
    else:
        print(f"{obj2} is not hashable")

    complexObj1 = ComplexObj("Asia", "Complex Obj Asia", "Peter", 90318)
    complexObj2 = ComplexObj("Asia", "Complex Obj Asia", "Peter", 90318)
    print(f"complexObj1 == complexObj2: {complexObj1 == complexObj2}")
    print(f"hash(complexObj1): {hash(complexObj1)}, hash(complexObj2)) = {hash(complexObj2)}")
    print(f"id(complexObj1) == id(complexObj2): {id(complexObj1) == id(complexObj2)}")
    print(f"id(complexObj1): {id(complexObj1)}, id(complexObj2): {id(complexObj2)}")