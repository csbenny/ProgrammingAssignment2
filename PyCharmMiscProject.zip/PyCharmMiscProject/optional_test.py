from typing import Optional

def test_optional(x: Optional[int]):
    if x is None:
        print("x is None")
    else:
        print(f"x is {x}")

if __name__ == '__main__':
    a = None
    b = 1

    test_optional(a)
    test_optional(b)