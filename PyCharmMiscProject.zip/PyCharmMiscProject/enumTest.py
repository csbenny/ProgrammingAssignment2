from enum import Enum

class OrderSide(Enum):
    BUY = "Buy"
    SELL = "Sell"

class OrderType(Enum):
    MARKET = "Market"
    LIMIT = "Limit"
    STOP = "Stop loss"
    GTC = "Good Till Cancelled"

class Order:
    def __init__(self, symbol:str, side:OrderSide, orderType:OrderType, price:float, quantity:int):
        self.symbol = symbol
        self.side = side
        self.orderType = orderType
        self.price = price
        self.quantity = quantity

    def __str__(self) -> str:
        return f"{self.orderType.value} {self.side.value} ORDER on {self.symbol} with qty {self.quantity} @ {self.price}"


if __name__ == "__main__":
    print("Program start")

    portfolio = (
        Order('0005.HK', OrderSide.BUY, OrderType.MARKET, 56.5, 2_000),
        Order('0700.HK', OrderSide.SELL, OrderType.LIMIT, 123.8, 38_000),
        Order('0700.HK', OrderSide.SELL, OrderType.GTC, 123.8, 38_000)
    )

    for order in portfolio:
        print(order)