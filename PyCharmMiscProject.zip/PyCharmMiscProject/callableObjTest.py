class CallableObjUseCase1:
    def __init__(self):
        pass

    def __call__(self, *args):
        print(type(args))
        return sum(args)

class CallableObjUseCase2:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        print(f"Before calling the function {self.func.__name__}. Pos args: {args}, Kw args: {kwargs}")
        result = self.func(*args, **kwargs)
        print(f"After calling the function {self.func.__name__}. Pos args: {args}, Kw args: {kwargs}")
        return result

class CallableObjStateful:
    def __init__(self):
        self.counter = 0

    def __call__(self, *args, **kwargs):
        self.counter += 1
        return self.counter
    
class NoDiscount:
    def __init__(self):
        self.discountRate = 0
        
    def __call__(self, price):
        self.price = price * (1 - self.discountRate)
        return self.price
    
class FixedDiscount:
    def __init__(self, discountRate):
        self.discountRate = discountRate

    def __call__(self, price):
        self.price = price * (1 - self.discountRate)
        return self.price

class RandomDiscount:
    def __init__(self):
        import random
        # Random discount rate up to 50%
        self.discountRate = random.uniform(0,0.5)

    def __call__(self, price):
        import random
        self.price = price * (1 - self.discountRate)
        print(f"Random discount rate: {self.discountRate}")
        return self.price

class Product:
    def __init__(self, name, price, discountStrategy):
        self.name = name
        self.price = price
        self.discountStrategy = discountStrategy

    def getPrice(self):
        return self.discountStrategy(self.price)

@CallableObjUseCase2
def greeting(text, country="Hong Kong"):
    print(f"Hello {text} from {country}")

if __name__ == "__main__":
    obj = CallableObjUseCase1()

    #Use case 1: The object can be called like a function
    result = obj(1, 2, 3, 4, 5)
    print(f"Result: {result}")

    #Use case 2: Class decorator
    greeting("Callable Object Test", country="USA")

    #Use case 3: Stateful callable object (e.g. Counter)
    statefulcallobj = CallableObjStateful()
    print(f"Counter: {statefulcallobj()}")
    print(f"Counter: {statefulcallobj()}")
    print(f"Counter: {statefulcallobj()}")

    #Use case 4: Strategy pattern (Class itself acts like a function) 
    p1 = Product("iPhone 16", 10000, NoDiscount())
    p2 = Product("iPhone 15", 10000, FixedDiscount(0.2))
    p3 = Product("iPhone 14", 10000, RandomDiscount())
    print(f"Prices: p1: {p1.getPrice()}, p2: {p2.getPrice()}, p3: {p3.getPrice()}")