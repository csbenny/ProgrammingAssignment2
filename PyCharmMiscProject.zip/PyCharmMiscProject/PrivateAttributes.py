class Book:
    def __init__(self, title, author, year, price):
        # public attributes
        self.title = title
        self.author = author
        self.year = year
        # private attribute
        self.__price = price

    @property
    def price(self):
        return self.__price
    # getter method
    # def get_price(self):
    #     return self.__price

    def __repr__(self):
        return f"Book: {self.title}, Author: {self.author}, Year: {self.year}, Price: {self.price}"


# instantiating a new object
book1 = Book("Americanah", " Chimamanda Adichie", 2016, 6000)
book2 = Book("Teller of secrets", "Bisi Adjapon", 2021, 5000)
book3 = Book("Stay with me", "Ayobami Adebayo", 2017, 4000)

print(repr(book3))
print(book3.title)
print(book3.author)
print(book3.year)
print(book3.price)
