class Calculator1:
    def __init__(self, name, version):
        self.name = name
        self.version = version

    def add(self, a, b):
        return a + b

    def sub(self, a, b):
        return a - b

    def mul(self, a, b):
        return a * b

    def div(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b

class Calculator2:
    __slots__ = ['name', 'version', 'subversion']

    def __init__(self, name, version, subversion):
        self.name = name
        self.version = version
        self.subversion = subversion

    def add(self, a, b):
        return a + b

    def sub(self, a, b):
        return a - b

    def mul(self, a, b):
        return a * b

    def div(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b


if __name__ == "__main__":
    print("Program start")
    cal1 = Calculator1('First calculator', 1.0)
    cal1.customField = 'Custom field value'
    print(dir(cal1))
    print(f"Sample check of __dict__ in dir() result: {'__dict__' in dir(cal1)}")
    if hasattr(cal1, '__dict__'):
        print("cal1 has __dict__ attribute")
        print(f"cal1 __dict__ content: {cal1.__dict__}")
    else:
        print('cal1 does not have __dict__ attribute')

    cal2 = Calculator2('Second calculator', 1.0, 0.5)
    #Below statement will raise AttributeError as having __slots__ prevents adding new attributes dynamically
    # cal2.customField = 'Custom field value'
    print(dir(cal2))
    print(f"Sample check of __dict__ in dir() result: {'__dict__' in dir(cal2)}")
    if hasattr(cal2, '__dict__'):
        print('cal2 has __dict__ attribute')
        print(f"cal2 __dict__ content: {cal2.__dict__}")
    else:
        print('cal2 does not have __dict__ attribute')
        print(f"cal2 __slots__ content: {cal2.__slots__}")

