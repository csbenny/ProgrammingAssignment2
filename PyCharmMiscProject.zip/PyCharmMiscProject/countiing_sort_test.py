def counting_sort(arr: list[int]) -> list[int]:
    count_dict = {}

    for num in arr:
        count_dict[num] = count_dict.get(num, 0) + 1

    sorted_list =  sorted(count_dict.items(), key=lambda item: item[0])

    new_list = []
    for num, count in sorted_list:
        new_list.extend([num] * count)

    return new_list

if __name__ == '__main__':
    print("Program start")
    arr = [4, 2, 2, 8, 3, 3, 1]
    sorted_arr = counting_sort(arr)

    print(f"Original array: {arr}")
    print(f"Sorted array: {sorted_arr}")
