"""
It is a simple string manipulation challenge. You have to replace the space with a specific character.

Origin: https://www.datacamp.com/blog/top-python-interview-questions-and-answers
"""

from functools import wraps
import time

def timerWrapper(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = func(*args, **kwargs)
        timetaken = time.time() - t1
        print(f"[Benchmarking] Function '{func.__name__}' finished in {timetaken}")
        return result
    return wrapper

@timerWrapper
def stringreplace(inputstr, replacechar):
    ans = []

    for c in inputstr:
        if c == ' ':
            c = replacechar

        ans.append(c)

    return "".join(ans)

@timerWrapper
def stringreplace2(inputstr, replacechar):
    return inputstr.replace(' ', replacechar)


text = "D t C mpBl ckFrid yS le"
ch = "a"

print(stringreplace(text,ch))
print(stringreplace2(text, ch))