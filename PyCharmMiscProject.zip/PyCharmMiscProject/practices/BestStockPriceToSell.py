from functools import wraps
import time


def timerWrapper(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = func(*args, **kwargs)
        timetaken = time.time() - t1
        print(f"[Benchmarking] Function '{func.__name__}' finished in {timetaken}")
        return result

    return wrapper


def can_segment_string(text, words):
    for i in range(len(text) + 1):
        s1 = s[0:i]
        if s1 in words:
            s2 = text[i:]
            if s2 == '' or s2 in words or can_segment_string(s2, words):
                return True
    return False


def buy_sell_stock_prices(prices: list[int]) -> tuple:
    current_buy = prices[0]
    global_sell = prices[1]
    global_profit = global_sell - current_buy

    for i in range(1, len(prices)):
        current_price = prices[i]
        current_profit = current_price - current_buy

        if current_profit > global_profit:
            global_profit = current_profit
            global_sell = current_price
        if current_price < current_buy:
            current_buy = current_price

    # global_profit = global_sell - global_buy
    # global_buy = global_sell - global-profit
    return global_sell - global_profit, global_sell


stock_prices_1 = [10, 9, 16, 17, 19, 23]
result1 = buy_sell_stock_prices(stock_prices_1)
print(result1)
# (9, 23)


stock_prices_2 = [8, 6, 5, 4, 3, 2, 1]
result2 = buy_sell_stock_prices(stock_prices_2)
print(result2)
# (6, 5)