class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def bfs(root: Node):
    if root is None:
        return

    queue = [ root ]
    while queue:
        current = queue.pop(0)
        print(current.value, end=' ')

        if current.left:
            queue.append(current.left)
        if current.right:
            queue.append(current.right)

def dfs_in_order(node: Node):
    if node is None:
        return

    dfs_in_order(node.left)
    print(node.value, end=' ')
    dfs_in_order(node.right)

def dfs_pre_order(node: Node):
    if node is None:
        return

    print(node.value, end=' ')
    dfs_pre_order(node.left)
    dfs_pre_order(node.right)

def dfs_post_order(node: Node):
    if node is None:
        return

    dfs_post_order(node.left)
    dfs_post_order(node.right)
    print(node.value, end=' ')

if __name__ == '__main__':
    # Example usage
    root = Node(1)
    root.left = Node(2)
    root.right = Node(3)
    root.left.left = Node(4)
    root.left.right = Node(5)

    # print("Root value:", root.value)
    # print("Left child value:", root.left.value)
    # print("Right child value:", root.right.value)
    # print("Left child's left child value:", root.left.left.value)
    # print("Left child's right child value:", root.left.right.value)

    print(" ".join(['-' * 10, " DF Pre-Order ", '-' * 10]))
    dfs_pre_order(root)
    print()
    print(" ".join(['-' * 10, " DFS In-Order ", '-' * 10]))
    dfs_in_order(root)
    print()
    print(" ".join(['-' * 10, " DFS Post-Order ", '-' * 10]))
    dfs_post_order(root)
    print()
    print(" ".join(['-' * 10, " BFS ", '-' * 10]))
    bfs(root)
    print()
    print('-' * 10)