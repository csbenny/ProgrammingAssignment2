from enum import Enum

class OrderSide(Enum):
    BUY = "Buy"
    SELL = "Sell"

class Order:
    def __init__(self, orderId:str, symbol:str, side: OrderSide, price: float, quantity: int):
        self.__orderId = orderId
        self.__symbol = symbol
        self.__side = side
        self.__price = price
        self.__quantity = quantity

    def __eq__(self, other):
        if isinstance(other, Order):
            return (self.__orderId == other.__orderId and
                    self.__symbol == other.__symbol and
                    self.__side == other.__side and
                    self.__price == other.__price and
                    self.__quantity == other.__quantity)
        return False

    def __hash__(self):
        return hash((self.orderId, self.symbol, self.side, self.price, self.quantity))

    @property
    def orderId(self):
        return self.__orderId

    @property
    def symbol(self):
        return self.__symbol

    @property
    def side(self):
        return self.__side

    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, new_price: float):
        if new_price < 0:
            raise ValueError("Price cannot be negative")
        self.__price = new_price

    @property
    def quantity(self):
        return self.__quantity

    @quantity.setter
    def quantity(self, new_quantity: int):
        self.__quantity = new_quantity

    def __str__(self) -> str:
        return f"Order[orderId: {self.orderId}, symbol: {self.symbol}, side: {self.side.value}, price: {self.price}, quantity: {self.quantity}]"

class OrderBook:
    def __init__(self):
        self.buyOrderBook = dict()
        self.sellOrderBook = dict()
        self.orderDict = dict()

    def get_order_book(self, side: OrderSide):
        if side == OrderSide.BUY:
            return self.buyOrderBook
        elif side == OrderSide.SELL:
            return self.sellOrderBook
        else:
            raise ValueError(f"Invalid side: {side}")

    def ensure_price_levels_valid(self, side: OrderSide, price: float):
        order_book = self.get_order_book(side)
        if price in order_book and len(order_book[price]) == 0:
            print(f"Cleaning up price level {price} from {side.value} order book")
            del order_book[price]

    def add_order(self, orderId: str, symbol: str, side: OrderSide, price: float, quantity: int):
        o = Order(orderId, symbol, side, price, quantity)
        if orderId in self.orderDict:
            del self.orderDict[orderId]
        self.orderDict[orderId] = o

        ob = self.get_order_book(side)
        if price not in ob:
            ob[price] = []
        ob[price].append(o)
        print(f"Added order: {o}")

    def remove_order(self, order_id: str):
        if order_id in self.orderDict:
            o = self.orderDict[order_id]
            order_book = self.get_order_book(o.side)
            if o.price in order_book:
                order_list = order_book[o.price]
                order_list.remove(o)
                print(f"Removed order: {o}")

                self.ensure_price_levels_valid(o.side, o.price)
            else:
                print(f"No price level {o.price} can be found in order book. No action")

    def update_order(self, orderId: str, new_price: float, new_quantity: int):
        if orderId in self.orderDict:
            o = self.orderDict[orderId]
            order_book = self.get_order_book(o.side)
            if new_price != o.price:
                self.remove_order(orderId)
                self.add_order(orderId, o.symbol, o.side, new_price, new_quantity)
                print(f"Update order {orderId} by removing and adding again @ price {new_price}")
            elif new_quantity != o.quantity:
               o.quantity = new_quantity
               print(f"Update order {orderId} by updating the order quantity as {new_quantity}")
        else:
            print(f"Order {orderId} cannot be found. No action")

    def print_order_book(self, side: OrderSide, level: int):
        order_book = self.get_order_book(side)
        price_levels = sorted(order_book.keys(), reverse=True if side == OrderSide.BUY else False)

        for o in order_book[price_levels[level]]:
            print(f"Order ID: {o.orderId}, Symbol: {o.symbol}, Side: {o.side.value}, Price: {o.price}, Quantity: {o.quantity}")

    def print_order_book(self):
        print("".join(['=' * 5, ' SELL ORDERBOOK ', '=' * 5]))
        sell_order_book = self.get_order_book(OrderSide.SELL)
        for price_level in sorted(sell_order_book.keys(), reverse=True):
            order_list = sell_order_book[price_level]
            for sell_order in order_list:
                print(sell_order)

        print("".join(['=' * 5, ' BUY ORDERBOOK ', '=' * 5]))
        buy_order_book = self.get_order_book(OrderSide.BUY)
        for price_level in sorted(buy_order_book.keys(), reverse=True):
            order_list = buy_order_book[price_level]
            for buy_order in order_list:
                print(buy_order)

if __name__ == '__main__':
    ob = OrderBook()

    print("1. Building up order book")
    ob.add_order("1", "AAPL", OrderSide.BUY, 150.0, 100)
    ob.add_order("2", "AAPL", OrderSide.SELL, 155.0, 50)
    ob.add_order("3", "AAPL", OrderSide.BUY, 152.0, 200)
    ob.add_order("4", "AAPL", OrderSide.SELL, 153.0, 150)

    print('-' * 10)
    ob.print_order_book()
    print('-' * 10)

    print("2. Updating order book")
    ob.update_order("1", 151.0, 120)
    ob.remove_order("2")

    ob.print_order_book()