"""
# Definition for an Interval.
class Interval:
    def __init__(self, start: int = None, end: int = None):
        self.start = start
        self.end = end
"""
class Interval:
    def __init__(self, start: int = None, end: int = None):
        self.start = start
        self.end = end

    def __str__(self):
        return f"Interval(start: {self.start}, end: {self.end})"

class Solution:
    def employeeFreeTime(self, schedule: list[list[Interval]]) -> list[Interval]:
        interval_list = [i for s in schedule for i in s]
        interval_list = sorted(interval_list, key=lambda k: k.start)

        ans = []
        current_interval = interval_list[0]
        for i in range(1, len(interval_list)):
            if interval_list[i].start <= current_interval.end:
                tmp_max = max(current_interval.end, interval_list[i].end)
                current_interval.end = tmp_max
            else:
                ans.append(Interval(current_interval.end, interval_list[i].start))
                current_interval = interval_list[i]
        return ans

if __name__ == '__main__':
    """
    Example 1:

Input: schedule = [[[1,2],[5,6]],[[1,3]],[[4,10]]]
Output: [[3,4]]
Explanation: There are a total of three employees, and all common
free time intervals would be [-inf, 1], [3, 4], [10, inf].
We discard any intervals that contain inf as they aren't finite.

Example 2:

Input: schedule = [[[1,3],[6,7]],[[2,4]],[[2,5],[9,12]]]
Output: [[5,6],[7,9]]
    """

    # [[[1,2],[5,6]],[[1,3]],[[4,10]]]
    schedule_list = [
        [Interval(1, 2), Interval(5, 6)],
        [Interval(1, 3)],
        [Interval(4, 10)]
    ]

    # [[[1,3],[6,7]],[[2,4]],[[2,5],[9,12]]]
    # schedule_list = [
    #     [Interval(1,3), Interval(6,7)],
    #     [Interval(2,4)],
    #     [Interval(2,5), Interval(9, 12)]
    # ]
    solution = Solution()
    result_list = solution.employeeFreeTime(schedule_list)
    for interval in result_list:
        print(f"Answer:{interval}")