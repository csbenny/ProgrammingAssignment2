"""
remove duplicates from a sorted array

https://leetcode.com/problems/remove-duplicates-from-sorted-array/editorial/
"""

from functools import wraps
import time

def timerWrapper(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = func(*args, **kwargs)
        timetaken = time.time() - t1
        print(f"[Benchmarking] Function '{func.__name__}' finished in {timetaken}")
        return result
    return wrapper


def can_segment_string(text, words):
    for i in range(len(text)+1):
        s1 = s[0:i]
        if s1 in words:
            s2 = text[i:]
            if s2 == '' or s2 in words or can_segment_string(s2, words):
                return True
    return False

@timerWrapper
def can_segment_string1(text, words):
    return can_segment_string(text, words)

@timerWrapper
def can_segment_string2(text, words):
    for w in words:
        if w in text:
            text = text.replace(w, '')
        if len(text) == 0:
            return True

    return False

def removeDuplicates(array):
    visit = array[0]
    index = 1
    for i in range(1, len(array)):
        current = array[i]
        if current != visit:
            array[index] = current
            index += 1
        visit = array[i]
    return index

array_1 = [1,2,2,3,3,4]
result1= removeDuplicates(array_1)
print(result1)
# 4


array_2 = [1,1,3,4,5,6,6]
result2 = removeDuplicates(array_2)
print(result2)
# 5L