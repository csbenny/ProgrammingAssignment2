class NoDiscount:
    def __init__(self, name: str):
        self.store_name = name
        self.discount_rate = 0.0

    def get_store_name(self):
        return self.store_name

    def get_price(self, amount: float) -> float:
        return amount * (1 - self.discount_rate)

class DiscountPricer:
    def __init__(self, store_name: str, discount_rate: float):
        self.store_name = store_name
        self.discount_rate = discount_rate

    def get_store_name(self):
        return self.store_name

    def get_price(self, amount: float) -> float:
        return amount * (1 - self.discount_rate)

class PricingService:
    def __init__(self, subject):
        self.real_subject = subject

    def get_store_name(self) -> str:
        # Direct delagation of the call to the real subject
        return self.real_subject.get_store_name()

    def get_price(self, amount: float) -> float:
        return self.real_subject.get_price(amount)

if __name__ == "__main__":
    print("proxy pattern demo")

    kwun_tong_store = NoDiscount("Kwun Tong Store")
    central_store = DiscountPricer("Central Store", 0.1)
    wanchai_store = DiscountPricer("Wan Chai Store", 0.3)

    amount = 100.0

    pricing_service = PricingService(kwun_tong_store)
    print(f"At {pricing_service.get_store_name()}, original price={amount}, final price={pricing_service.get_price(amount)}")

    pricing_service = PricingService(central_store)
    print(f"At {pricing_service.get_store_name()}, original price={amount}, final price={pricing_service.get_price(amount)}")

    pricing_service = PricingService(wanchai_store)
    print(f"At {pricing_service.get_store_name()}, original price={amount}, final price={pricing_service.get_price(amount)}")