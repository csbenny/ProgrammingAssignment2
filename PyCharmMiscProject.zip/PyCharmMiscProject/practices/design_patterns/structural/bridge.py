import yaml

class Output:
    def write(self, data: dict) -> str:
        pass

class YAMLOutput(Output):
    def write(self, data: dict) -> str:
        yaml_dump = yaml.dump(data)
        return yaml_dump

class PlainTextOutput(Output):
    def write(self, data:dict) -> str:
        return str(data)

# DictOutput is abstract from knowing how to generate the output text based on the data dict
class DictOutput:
    def __init__(self, data:dict, outputter: Output):
        self.data = data
        self.outputter = outputter

    def generate_from_dict(self) -> str:
        return self.outputter.write(self.data)

if __name__ == "__main__":
    print('bridge pattern demo')

    my_dict = { "Field " + str(i) : i ** 2 for i in range(1,11) }

    output = DictOutput(my_dict, YAMLOutput())
    print(output.generate_from_dict())