class ChinaPowerAdaptor:
    def __init__(self, name: str = "China Power Adatator"):
        self.name = name
        self.voltage = 110

    def get_power(self) -> int:
        return self.voltage

class UniversalPowerAdaptor:
    def __init__(self, name: str = "Universal Power Adaptor", base_adaptor = None):
        self.name = name
        self.base_adaptor = base_adaptor
        self.country_voltage_multipliers = {
            "Hong Kong": 2,
            "Singapore": 5,
            "China": 1
        }


    def get_power(self, country: str) -> int:
        #Adaptor adapts the interface by performing some transformation
        # different from proxy pattern which delagates the call to the real subject
        
        if country != "China":
            multiplier = self.country_voltage_multipliers.get(country, 1)
            print(f"For country {country}, the base voltage will be multiplied by {multiplier}")
            return self.base_adaptor.get_power() * multiplier
        else:
            return self.base_adaptor.get_power()

if __name__ == "__main__":
    print("Adaptor pattern demo")

    my_adaptor = UniversalPowerAdaptor(name="Universer adaptor" , base_adaptor = ChinaPowerAdaptor())
    hk_power = my_adaptor.get_power("Hong Kong")
    cn_power = my_adaptor.get_power("China")
    default_power = my_adaptor.get_power("Singapore")

    print(f"Hong Kong Power: {hk_power}, China Power: {cn_power}, Singapore Power: {default_power}")


