class Component:
    def action(self, data:str):
        pass

class Appender(Component):
    def __init__(self, prefix:str = None, suffix:str = None):
        self.prefix = prefix
        self.suffix = suffix

    def action(self, data: str):
        print(f"Appender: {self.prefix if self.prefix else ''}{data}{self.suffix if self.suffix else ''}")

class Echoer(Component):
    def action(self, data: str):
        print(f"Echoer: {data}")

class Composite(Component):
    def __init__(self):
        self.components = []

    def add_component(self, component: Component):
        self.components.append(component)

    def action(self, data: str):
        for component in self.components:
            component.action(data)

if __name__ == '__main__':
    print("Composite pattern demo")

    composite = Composite()
    composite.add_component(Echoer())
    composite.add_component(Appender("Hello ", None))
    composite.add_component(Echoer())
    composite.add_component(Appender(None, " Goodbye!"))

    composite.action("Benny")

