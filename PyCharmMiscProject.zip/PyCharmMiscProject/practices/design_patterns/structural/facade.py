class DataLoader:
    def load(self, datasource: str):
        print(f"DataLoader loads data from {datasource}")

class StrategyFinder:
    def load(self, strategy_name: str):
        print(f"Finding trading strategy {strategy_name}")

class ContainerAllocator:
    def allocate(self, memory: int, no_of_cores: int):
        print(f"Allocating algo container with memory: {memory}MB with {no_of_cores} cores")

class BackTester:
    def __init__(self, datasource: str, strategy_name: str, memory: int, no_of_cores: int):
        self.datasource = datasource
        self.strategy_name = strategy_name
        self.memory = memory
        self.no_of_cores = no_of_cores

    def run(self):
        loader, finder, allocator = DataLoader(), StrategyFinder(), ContainerAllocator()
        print(f"Running backtest with [datasource: {self.datasource}, strategy_name: {self.strategy_name}, memory={self.memory}, no_of_cores: {self.no_of_cores}]")
        loader.load(self.datasource)
        finder.load(self.strategy_name)
        allocator.allocate(self.memory, self.no_of_cores)

if __name__ == '__main__':
    print('facade pattern demo')

    backtester = BackTester("PROD-DB", "MarketMaking-XHKG", 8192, 32)
    backtester.run()