class JDKProfile:
    def __init__(self, jdk_version: str, os_version: str, environment: str):
        self.jdk_version = jdk_version
        self.os_version = os_version
        self.environment = environment

    def download(self):
        print(f"Download JDK version {self.jdk_version} for OS {self.os_version} under environment {self.environment}")

class JDKFlyWeight:
    def __init__(self):
        self.jdk_repo = dict()

    def get_jdk(self, jdk_version: str, os_version: str, environment: str):
        key = (jdk_version, os_version, environment)
        if key not in self.jdk_repo:
            print(f"New profile discover for jdk {jdk_version} on OS {os_version} under environment {environment}")
            self.jdk_repo[key] = JDKProfile(jdk_version, os_version, environment)
        return self.jdk_repo[key]

if __name__ == '__main__':
    print('Flyweight pattern demo')

    jdk_version = ["jdk1.8", "jdk11", "jdk17"]
    os_version = ["Redhat 7.9"]
    environment = ["PROD", "UAT"]

    flyweight = JDKFlyWeight()

    all_combinations = [(i, j, k) for i in jdk_version for j in os_version for k in environment]

    for jdk, os, env in all_combinations:
        jdk_profile = flyweight.get_jdk(jdk, os, env)
        jdk_profile.download()

    print('-' * 10)
    profile = flyweight.get_jdk("jdk17", "Redhat 7.9", "PROD")
    profile.download()