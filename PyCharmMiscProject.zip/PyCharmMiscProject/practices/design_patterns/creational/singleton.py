class SingletonItem:
    __instance = None

    def __init__(self, name: str):
        self.__name = name

    @staticmethod
    def get_instance(name: str):
        if SingletonItem.__instance is None:
            print(f'Creating new instance of SingletonItem with name: {name}')
            SingletonItem.__instance = SingletonItem(name)
        else:
            print(f'Returning existing instance of SingletonItem with name: {SingletonItem.__instance.__name}')
        return SingletonItem.__instance

    def print_name(self):
        print(f"My name is '{self.__name}'")


if __name__ == '__main__':
    print("start")

    obj1 = SingletonItem.get_instance('Singleton object')
    obj2 = SingletonItem.get_instance('Singleton object')

    if obj1 is obj2:
        print(f"The two objects are the same instance. id(obj1) = {id(obj1)} vs id(obj2) = {id(obj2)}")
        obj1.print_name()

    obj3 = SingletonItem("Another instance")
    if obj1 is obj3:
        print("obj3 is still the same instance as obj1")
    else:
        print(f"obj3 is a separate instance. id(obj1) = {id(obj1)} vs id(obj3) = {id(obj3)}")
        obj3.print_name()

    print("end")