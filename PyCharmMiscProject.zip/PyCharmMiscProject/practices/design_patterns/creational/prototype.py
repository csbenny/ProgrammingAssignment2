import copy

class Clonable:
    def clone(self):
        return copy.deepcopy(self)

class EmployeeTemplate(Clonable):
    def __init__(self, ranking: str, position: str, description: str,  data: dict):
        self.ranking = ranking
        self.position = position
        self.description = description
        self.data = data

    def set_data(self, **args):
        self.data.update(**args)

    def __str__(self):
        return f"[Employee Profile| ranking: {self.ranking}, position: {self.position}, description: {self.description}, data: {self.data}]"

if __name__ == '__main__':
    print("prototype pattern demo")

    senior_engineer_profile = EmployeeTemplate("VP", "Senior Engineer", "Senior Engineer in charge of the team", {"Manager": "Elon Mask", "Bonus": 1000})

    engineer1 = senior_engineer_profile.clone()
    engineer1.set_data(Alias="Engineer 1", Name="Simon Tang", Salary=10_000, Bonus=3000, Married=False)

    engineer2 = senior_engineer_profile.clone()
    engineer2.ranking = "SVP"
    engineer2.set_data(Alias="Engineer 2", Name="Terry Fung", Salary=15_000, Bonus=2000, Married=True)

    print(engineer1)
    print(engineer2)