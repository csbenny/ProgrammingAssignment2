class Singleton2:
    __instance = None

    # def __init__(self, name: str, surname: str = "N/A"):
    #     print(f"Running __init__ with name: {name}, surname: {surname}")
    #     self.name = name
    #     self.surname = surname

    def __new__(cls, name:str, surname:str):
        if cls.__instance is None:
            cls.__instance = super().__new__(cls)
            cls.__instance.name = name
            cls.__instance.surname = surname

        return cls.__instance

    def print_name(self):
        print(f"My name is {self.name}, {self.surname}")

if __name__ == '__main__':
    print('start')

    obj1 = Singleton2("Patrick", "Chan")
    obj2 = Singleton2("Nelson", "Ng")

    if obj1 is obj2:
        print(f"obj1 and obj2 are the same instance. id(obj1) = {id(obj1)} vs id(obj2) = {id(obj2)}")
        obj1.print_name()

    obj3 = Singleton2("Donald", "Trump")
    if obj1 is obj3:
        print("obj1 and obj3 are the same instance")
    else:
        print("obj1 and obj3 are different instances")

    obj1.print_name()
    obj3.print_name()

    print('end')