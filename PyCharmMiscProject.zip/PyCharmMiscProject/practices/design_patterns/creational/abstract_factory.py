
class MacGUIFactory:
    def create_button(self):
        return "MacOS button"

    def create_frame(self):
        return "MacOS frame"

class WindowGUIFactory:
    def create_button(self):
        return "Window button"

    def create_frame(self):
        return "Window frame"

class OSGUIFactory:
    @staticmethod
    def get_factory(os: str):
        if os == "Window":
            return WindowGUIFactory()
        elif os == "Mac":
            return MacGUIFactory()
        else:
            return None


if __name__ == '__main__':
    print("Abstract factory demo")

    factory = OSGUIFactory.get_factory("Window")
    print(factory.create_frame())
    print(factory.create_button())

    factory = OSGUIFactory.get_factory("Mac")
    print(factory.create_frame())
    print(factory.create_button())