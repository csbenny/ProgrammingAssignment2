class Observer:
    def onEvent(self, event: str):
        pass

class EchoObserver(Observer):
    def onEvent(self, event: str):
        print(f"EchoObserver: Received event: {event}")

    def __str__(self):
        return f"EchoObserver"

class ToUpperCaseObserver(Observer):
    def onEvent(self, event: str):
        print(f"ToUpperCaseObserver: Received event: {event.upper()}")

    def __str__(self):
        print(f"ToUpperCaseObserver")

class Subject:
    def __init__(self):
        self.observer_list = []

    def add_observer(self, observer: Observer):
        self.observer_list.append(observer)

    def remove_observer(self, observer: Observer):
        if observer in self.observer_list:
            print(f"Removing observer: {observer}")
            self.observer_list.remove(observer)

    def generate_event(self, event: str):
        print(f"Subject: Generating event: {event} ... ")

        for observer in self.observer_list:
            observer.onEvent(event)

if __name__ == '__main__':
    print('start')

    subject = Subject()

    observer1 = EchoObserver()
    observer2 = ToUpperCaseObserver()

    subject.add_observer(observer1)
    subject.add_observer(observer2)

    subject.generate_event("Start working please")
    subject.generate_event("Working hard")
    subject.generate_event("You can off now")

    subject.remove_observer(observer1)
    subject.generate_event("Is there anyone left")




