
class PricingContext:
    def __init__(self, underlying: str, asset_type: str, lot_size: int, expiry_date: str, model_version: str, pricing_data: dict):
        self.underlying = underlying
        self.asset_type = asset_type
        self.lot_size = lot_size
        self.expiry_date = expiry_date
        self.model_version = model_version
        self.pricing_data = pricing_data

    def __str__(self):
        return (f"PricingContext(underlying={self.underlying}, asset_type={self.asset_type}, "
                f"lot_size={self.lot_size}, expiry_date={self.expiry_date}, "
                f"model_version={self.model_version}, pricing_data={self.pricing_data})")

class PricingContextBuilder:
    def __init__(self):
        self.reset_attributes()

    def reset_attributes(self):
        self.underlying = None
        self.asset_type = None
        self.lot_size = None
        self.expiry_date = None
        self.model_version = None
        self.pricing_data = None

    def set_underlying(self, underlying: str):
        self.underlying = underlying
        return self

    def set_asset_type(self, asset_type: str):
        self.asset_type = asset_type
        return self

    def set_lot_size(self, lot_size: int):
        self.lot_size = lot_size
        return self

    def set_expiry_date(self, expiry_date: str):
        self.expiry_date = expiry_date
        return self

    def set_model_version(self, model_version: str):
        self.model_version = model_version
        return self

    def set_pricing_data(self, pricing_data: dict):
        self.pricing_data = pricing_data
        return self

    def build(self) -> PricingContext:
        new_context = PricingContext(self.underlying, self.asset_type, self.lot_size, self.expiry_date, self.model_version, self.pricing_data)

        # Reset the builder state for future builds
        self.reset_attributes()

        return new_context


if __name__ == '__main__':
    print("builder pattern demo")

    builder = PricingContextBuilder()

    (builder.set_underlying("0005.HK").set_asset_type("Stock").set_lot_size(400).set_expiry_date("2028-12-31")
    .set_model_version("v1.34").set_pricing_data({"vol_surface_id": 12345, "div_curve_id": 54321}))

    pricing_context1 = builder.build()

    print(pricing_context1)

    pricing_context2 = builder.set_underlying("0700.HK").build()

    print(pricing_context2)



