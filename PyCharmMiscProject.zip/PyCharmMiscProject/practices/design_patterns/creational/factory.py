class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def __init__(self, name: str):
        self.name = name

    def speak(self):
        print(f"Wo wo wo....")

class Cat(Animal):
    def __init__(self, name:str):
        self.name = name

    def speak(self):
        print(f"Meow meow meow....")

class AnimalFactory:
    @staticmethod
    def get_animal(genre: str, name: str) -> Animal:
        if genre == 'dog':
            return Dog(name)
        elif genre == 'cat':
            return Cat(name)
        else:
            raise ValueError(f"Unknown animal type {genre}")

if __name__ == '__main__':
    cat = AnimalFactory.get_animal('cat', 'Moeh sen')
    dog = AnimalFactory.get_animal('dog', '8 gor')
    # monkey = AnimalFactory.get_animal('monkey', 'King Kong')

    cat.speak()
    dog.speak()
    # monkey.speak()