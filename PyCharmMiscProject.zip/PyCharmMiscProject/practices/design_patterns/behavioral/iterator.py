class DataStore:
    def __init__(self, max_no_item: int):
        self.counter = 0
        self.max_no_item = max_no_item

    def __iter__(self):
        return self

    def __next__(self) -> int:
        if self.counter < self.max_no_item:
            tmp = self.counter * 10
            self.counter += 1
            return tmp
        else:
            raise StopIteration

    def __str__(self):
        return f"DataStore[counter: {self.counter}, max_no_item: {self.max_no_item}]"

if __name__ == '__main__':
    print("Iterator patter demo")

    ds = DataStore(5)

    for item in ds:
        print(item)