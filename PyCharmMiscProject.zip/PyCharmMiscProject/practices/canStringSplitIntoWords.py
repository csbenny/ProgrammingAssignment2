"""
You are provided with a large string and a dictionary of the words. You have to find if the input string can be segmented into words using the dictionary or not.

Origin: https://www.datacamp.com/blog/top-python-interview-questions-and-answers
"""

from functools import wraps
import time

def timerWrapper(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        t1 = time.time()
        result = func(*args, **kwargs)
        timetaken = time.time() - t1
        print(f"[Benchmarking] Function '{func.__name__}' finished in {timetaken}")
        return result
    return wrapper


def can_segment_string(text, words):
    for i in range(len(text)+1):
        s1 = s[0:i]
        if s1 in words:
            s2 = text[i:]
            if s2 == '' or s2 in words or can_segment_string(s2, words):
                return True
    return False

@timerWrapper
def can_segment_string1(text, words):
    return can_segment_string(text, words)

@timerWrapper
def can_segment_string2(text, words):
    for w in words:
        if w in text:
            text = text.replace(w, '')
        if len(text) == 0:
            return True

    return False

s = "datacamplack"
dictionary = ["data", "camp", "cam", "lack"]
result1 = can_segment_string1(s, dictionary)
print(result1)
result2 = can_segment_string2(s, dictionary)
print(result2)
# True
