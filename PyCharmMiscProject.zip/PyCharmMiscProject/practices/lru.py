class LinkedNode:
    def __init__(self, key: int, val: int):
        self.key = key
        self.value = val
        self.next = None
        self.prev = None

class LRUCache:

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.mapping = dict()
        self.head = LinkedNode(-1, -1)
        self.tail = LinkedNode(-1, -1)
        self.head.next = self.tail
        self.tail.prev = self.head

    def add_node(self, node: LinkedNode):
        prev_end = self.tail.prev
        prev_end.next = node
        node.prev = prev_end
        node.next = self.tail
        self.tail.prev = node

    def remove_node(self, node: LinkedNode):
        node.prev.next = node.next
        node.next.prev = node.prev

    def get(self, key: int) -> int:
        if key in self.mapping:
            # update lru ds
            existing_node = self.mapping[key]
            self.remove_node(existing_node)
            self.add_node(existing_node)

            return existing_node.value
        else:
            return -1

    def put(self, key: int, value: int) -> None:
        if key in self.mapping:
            old_node = self.mapping[key]
            self.remove_node(old_node)

        new_node = LinkedNode(key, value)
        self.mapping[key] = new_node
        self.add_node(new_node)

        if len(self.mapping) > self.capacity:
            node_to_remove = self.head.next
            self.remove_node(node_to_remove)
            del self.mapping[node_to_remove.key]

# Your LRUCache object will be instantiated and called as such:
"""
Example 1:

Input
["LRUCache", "put", "put", "get", "put", "get", "put", "get", "get", "get"]
[[2], [1, 1], [2, 2], [1], [3, 3], [2], [4, 4], [1], [3], [4]]
Output
[null, null, null, 1, null, -1, null, -1, 3, 4]

Explanation
LRUCache lRUCache = new LRUCache(2);
lRUCache.put(1, 1); // cache is {1=1}
lRUCache.put(2, 2); // cache is {1=1, 2=2}
lRUCache.get(1);    // return 1
lRUCache.put(3, 3); // LRU key was 2, evicts key 2, cache is {1=1, 3=3}
lRUCache.get(2);    // returns -1 (not found)
lRUCache.put(4, 4); // LRU key was 1, evicts key 1, cache is {4=4, 3=3}
lRUCache.get(1);    // return -1 (not found)
lRUCache.get(3);    // return 3
lRUCache.get(4);    // return 4
"""
lru_cache = LRUCache(2)
print(lru_cache.put(1, 1))
print(lru_cache.put(2, 2))
print(lru_cache.get(1))
print(lru_cache.put(3, 3))
print(lru_cache.get(2))
print(lru_cache.put(4, 4))
print(lru_cache.get(1))
print(lru_cache.get(3))
print(lru_cache.get(4))
