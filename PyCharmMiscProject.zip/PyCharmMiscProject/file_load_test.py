import yaml

def read_file_line_by_line():
    with open('sample.txt', 'r') as file:
        content_in_lines = file.readlines()
        for line in content_in_lines:
            print(line.strip())

def read_whole_file():
    with open('sample.txt' ,'r') as file:
        content = file.read()
    print(content)

def read_yaml_file():
    with open('sample.yaml', 'r') as file:
        content = yaml.safe_load(file)
        print(type(content))
        print(content)

if __name__ == '__main__':
    # read_whole_file()
    # read_file_line_by_line()
    read_yaml_file()