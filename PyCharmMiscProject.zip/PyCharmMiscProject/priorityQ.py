import heapq as pq

h = []
pq.heappush(h, 5)
pq.heappush(h, 9)
pq.heappush(h, 3)
pq.heappush(h, 1)
pq.heappush(h, 7)

top3LargeList = pq.nlargest(3, h)
print(top3LargeList)

top3SmallList = pq.nsmallest(3, h)
print(top3SmallList)

#This wont be able iterate the list in sorted manner
l1 = [ h[i] for i in range(len(h)) ]
print(l1)

print(f"Before h: {h}")
#if you wanted to keep the original heap intact, you can copy it
clonedh = h.copy()
l2 = [ pq.heappop(clonedh) for i in range(len(clonedh))]
print(l2)

print(f"After h: {h}")